﻿namespace TrainWebApp.Model
{
    public enum RailCarType
    {
        BOX_CAR,
        COAL_CAR,
        COVERED_HOPPER,
        OIL_TANK
    }
}
